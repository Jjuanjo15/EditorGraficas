namespace EditorGraficasVectoriales;

public partial class FrmEditor : Form
{
    private Point puntoInicial;
    private Point puntoFinal;
    private bool dibujando = false;
    private bool modoDibujo = false;
    private bool modoSeleccionar = false;
    private List<Trazo> trazos = new List<Trazo>();
    private Trazo trazoSeleccionado = null;

    public FrmEditor()
    {
        InitializeComponent();
        cmbTrazo.Items.Clear();
        cmbTrazo.Items.Add("Linea");
        cmbTrazo.Items.Add("Rect�ngulo");
        cmbTrazo.Items.Add("Elipse");
        cmbTrazo.SelectedIndex = 0;
    }

    private void btnDibujar_Click(object sender, EventArgs e)
    {
        modoDibujo = !modoDibujo;
        modoSeleccionar = false;
        btnDibujar.Text = modoDibujo ? "Dibujar (Activo)" : "Dibujar";
        btnSeleccionar.Text = "Seleccionar";
    }

    private void btnSeleccionar_Click(object sender, EventArgs e)
    {
        modoSeleccionar = !modoSeleccionar;
        modoDibujo = false;
        btnSeleccionar.Text = modoSeleccionar ? "Seleccionar (Activo)" : "Seleccionar";
        btnDibujar.Text = "Dibujar";
    }

    private void pnlDibujo_MouseDown(object sender, MouseEventArgs e)
    {
        if (modoDibujo && e.Button == MouseButtons.Left)
        {
            puntoInicial = e.Location;
            dibujando = true;
        }
        else if (modoSeleccionar && e.Button == MouseButtons.Left)
        {
            trazoSeleccionado = trazos.FirstOrDefault(t => t.ContienePunto(e.Location));
            if (trazoSeleccionado != null)
            {
                trazoSeleccionado.Seleccionado = true;
                pnlDibujo.Invalidate();
            }
        }
    }

    private void pnlDibujo_MouseMove(object sender, MouseEventArgs e)
    {
        if (modoDibujo && dibujando)
        {
            puntoFinal = e.Location;
            pnlDibujo.Invalidate();
        }
    }

    private void pnlDibujo_MouseUp(object sender, MouseEventArgs e)
    {
        if (modoDibujo && e.Button == MouseButtons.Left)
        {
            dibujando = false;
            puntoFinal = e.Location;

            string tipo = cmbTrazo.SelectedItem.ToString();
            Trazo trazo = new Trazo(tipo, puntoInicial, puntoFinal);
            trazos.Add(trazo);
            pnlDibujo.Invalidate();
        }
    }

    private void pnlDibujo_Paint(object sender, PaintEventArgs e)
    {
        using (Pen pen = new Pen(Color.White, 2))
        {
            foreach (var trazo in trazos)
            {
                switch (trazo.Tipo)
                {
                    case "Linea":
                        e.Graphics.DrawLine(pen, trazo.PuntoInicial, trazo.PuntoFinal);
                        break;
                    case "Rect�ngulo":
                        e.Graphics.DrawRectangle(pen, new Rectangle(trazo.PuntoInicial,
                            new Size(trazo.PuntoFinal.X - trazo.PuntoInicial.X, trazo.PuntoFinal.Y - trazo.PuntoInicial.Y)));
                        break;
                    case "Elipse":
                        e.Graphics.DrawEllipse(pen, new Rectangle(trazo.PuntoInicial,
                            new Size(trazo.PuntoFinal.X - trazo.PuntoInicial.X, trazo.PuntoFinal.Y - trazo.PuntoInicial.Y)));
                        break;
                }

                if (dibujando)
                {
                    switch (cmbTrazo.SelectedItem.ToString())
                    {
                        case "Linea":
                            e.Graphics.DrawLine(pen, puntoInicial, puntoFinal);
                            break;
                        case "Rect�ngulo":
                            e.Graphics.DrawRectangle(pen, new Rectangle(puntoInicial,
                                new Size(puntoFinal.X - puntoInicial.X, puntoFinal.Y - puntoInicial.Y)));
                            break;
                        case "Elipse":
                            e.Graphics.DrawEllipse(pen, new Rectangle(puntoInicial,
                                new Size(puntoFinal.X - puntoInicial.X, puntoFinal.Y - puntoInicial.Y)));
                            break;
                    }
                }

                if (modoSeleccionar && trazo == trazoSeleccionado)
                {
                    using (Pen penSeleccion = new Pen(Color.Red, 2) { DashStyle = System.Drawing.Drawing2D.DashStyle.Dot })
                    {
                        e.Graphics.DrawRectangle(penSeleccion, new Rectangle(trazo.PuntoInicial,
                            new Size(trazo.PuntoFinal.X - trazo.PuntoInicial.X, trazo.PuntoFinal.Y - trazo.PuntoInicial.Y)));
                    }
                }
            }
        }
    }

    public static bool GuardarArchivo(string nombreArchivo, string[] lineas)
    {
        if (lineas != null)
        {
            try
            {
                using (StreamWriter sw = new StreamWriter(nombreArchivo))
                {
                    foreach (string linea in lineas)
                    {
                        sw.WriteLine(linea);
                    }
                }
                return true;
            }
            catch (IOException)
            {
                return false;
            }
        }
        return false;
    }

    private void btnGuardar_Click(object sender, EventArgs e)
    {
        using (SaveFileDialog saveFileDialog = new SaveFileDialog())
        {
            saveFileDialog.Filter = "Archivos de texto (*.txt)|*.txt|Todos los archivos (*.*)|*.*";
            saveFileDialog.Title = "Guardar dibujo";

            if (saveFileDialog.ShowDialog() == DialogResult.OK)
            {
                string nombreArchivo = saveFileDialog.FileName;

                List<string> lineas = new List<string>();
                foreach (var trazo in trazos)
                {
                    lineas.Add(trazo.GuardarComoTexto());
                }

                bool exito = GuardarArchivo(nombreArchivo, lineas.ToArray());

                if (exito)
                {
                    MessageBox.Show("Dibujo guardado exitosamente en " + nombreArchivo);
                }
                else
                {
                    MessageBox.Show("Error al guardar el dibujo.");
                }
            }
        }
    }

    private void btnAbrir_Click(object sender, EventArgs e)
    {
        using (OpenFileDialog openFileDialog = new OpenFileDialog())
        {
            openFileDialog.Filter = "Archivos de texto (*.txt)|*.txt|Todos los archivos (*.*)|*.*";
            openFileDialog.Title = "Abrir dibujo";

            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                string nombreArchivo = openFileDialog.FileName;
                string[] lineas = File.ReadAllLines(nombreArchivo);
                trazos.Clear();
                foreach (var linea in lineas)
                {
                    Trazo trazo = Trazo.CargarDesdeTexto(linea);
                    if (trazo != null)
                    {
                        trazos.Add(trazo);
                    }
                }
                pnlDibujo.Invalidate();
                MessageBox.Show("Dibujo cargado exitosamente desde " + nombreArchivo);
            }
        }
    }

    private void LimpiarDibujo()
    {
        trazos.Clear();
        pnlDibujo.Invalidate();
    }

    private void btnLimpiar_Click(object sender, EventArgs e)
    {
        var resultado = MessageBox.Show("�Seguro que deseas limpiar el �rea de dibujo?",
            "Confirmar limpieza", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

        if (resultado == DialogResult.Yes)
        {
            LimpiarDibujo();
        }
    }

    private void btnBorrar_Click(object sender, EventArgs e)
    {
        trazos.RemoveAll(t => t.Seleccionado);
        trazoSeleccionado = null;
        pnlDibujo.Invalidate();
    }
}