﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EditorGraficasVectoriales
{
    public class Trazo
    {
        public string Tipo { get; set; }
        public Point PuntoInicial { get; set; }
        public Point PuntoFinal { get; set; }
        public bool Seleccionado { get; set; }

        public Trazo(string tipo, Point puntoInicial, Point puntoFinal)
        {
            Tipo = tipo;
            PuntoInicial = puntoInicial;
            PuntoFinal = puntoFinal;
        }

        public string GuardarComoTexto()
        {
            return $"{Tipo};{PuntoInicial.X},{PuntoInicial.Y};{PuntoFinal.X},{PuntoFinal.Y}";
        }

        public static Trazo CargarDesdeTexto(string linea)
        {
            try
            {
                var partes = linea.Split(';');
                if (partes.Length == 3)
                {
                    string tipo = partes[0];

                    var puntoInicialPartes = partes[1].Split(',');
                    var puntoFinalPartes = partes[2].Split(',');

                    Point puntoInicial = new Point(int.Parse(puntoInicialPartes[0]), int.Parse(puntoInicialPartes[1]));
                    Point puntoFinal = new Point(int.Parse(puntoFinalPartes[0]), int.Parse(puntoFinalPartes[1]));

                    return new Trazo(tipo, puntoInicial, puntoFinal);
                }
                else
                {
                    throw new FormatException("Formato inválido para cargar el trazo.");
                }
            }
            catch (Exception ex)
            {
                throw new Exception($"Error al cargar el trazo desde texto: {ex.Message}");
            }
        }

        public bool ContienePunto(Point punto)
        {
            Rectangle area = new Rectangle(PuntoInicial,
                new Size(PuntoFinal.X - PuntoInicial.X, PuntoFinal.Y - PuntoInicial.Y));
            area = Rectangle.Inflate(area, 5, 5);

            switch (Tipo)
            {
                case "Linea":
                    return Math.Abs((double)(punto.Y - PuntoInicial.Y) / (PuntoFinal.Y - PuntoInicial.Y + 0.01) -
                                    (double)(punto.X - PuntoInicial.X) / (PuntoFinal.X - PuntoInicial.X + 0.01)) < 0.1;
                case "Rectángulo":
                case "Elipse":
                    return area.Contains(punto);
                default:
                    return false;
            }
        }
    }
}